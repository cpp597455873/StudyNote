public class QuickUnion {
	int[] unionSet;


	public QuickUnion(int count) {
		unionSet = new int[count];
		for (int i = 0; i < count; i++) {
			unionSet[i] = i;
		}
	}

	boolean connected(int p1, int p2) {
		int p1Root = getRoot(p1);
		int p2Root = getRoot(p2);
		return p1Root == p2Root;

	}

	void union(int p1, int p2) {
		int p1Root = getRoot(p1);
		int p2Root = getRoot(p2);
		unionSet[p1Root] = unionSet[p2Root];
	}

	int getRoot(int p) {
		while (unionSet[p] != p)
			p = unionSet[p];
		return p;
	}
}
