import java.util.ArrayList;
import java.util.Random;

public class Test {

	static ArrayList<Integer> list = new ArrayList<Integer>();
	static ArrayList<Integer> list2 = new ArrayList<Integer>();
	static int count = 500000;
	static Random random = new Random();

	public static void main(String[] args) {
		for (int i = 0; i < count; i++) {
			list.add(random.nextInt(count));
			list.add(random.nextInt(count));
			list2.add(random.nextInt(count));
			list2.add(random.nextInt(count));
		}
		long s = System.currentTimeMillis();
		testQuickFind();
		System.out.println(System.currentTimeMillis() - s);

		s = System.currentTimeMillis();
		testQuickUnion();
		System.out.println(System.currentTimeMillis() - s);

		s = System.currentTimeMillis();
		testUnionFind();
		System.out.println(System.currentTimeMillis() - s);

		s = System.currentTimeMillis();
		testUnionFind2();
		System.out.println(System.currentTimeMillis() - s);

	}

	static void testQuickFind() {
		QuickFind quickFind = new QuickFind(count);
		for (int i = 0; i < list.size(); i++) {
			quickFind.union(list.get(i), list.get(++i));
		}
		int j = 0;
		for (int i = 0; i < list2.size(); i++) {
			if(quickFind.connected(list2.get(i), list2.get(++i)))j++;
		}
		System.out.println(j);
	}

	static void testQuickUnion() {
		QuickUnion quickUnion = new QuickUnion(count);
		for (int i = 0; i < list.size(); i++) {
			quickUnion.union(list.get(i), list.get(++i));
		}
		int j = 0;
		for (int i = 0; i < list2.size(); i++) {
			if(quickUnion.connected(list2.get(i), list2.get(++i)))j++;
		}
		System.out.println(j);
	}

	static void testUnionFind() {
		UnionFind unionFind = new UnionFind(count);
		for (int i = 0; i < list.size(); i++) {
			unionFind.union(list.get(i), list.get(++i));
		}
		int j = 0;
		for (int i = 0; i < list2.size(); i++) {
			if(unionFind.connected(list2.get(i), list2.get(++i)))j++;
		}
		System.out.println(j);
	}

	static void testUnionFind2() {
		UnionFind2 unionFind = new UnionFind2(count);
		for (int i = 0; i < list.size(); i++) {
			unionFind.union(list.get(i), list.get(++i));
		}
		int j = 0;
		for (int i = 0; i < list2.size(); i++) {
			if(unionFind.connected(list2.get(i), list2.get(++i)))j++;
		}
		System.out.println(j);
	}

}
