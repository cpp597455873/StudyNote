public class UnionFind {
	int[] sz;
	int[] unionSet;


	public UnionFind(int count) {
		sz = new int[count];
		unionSet = new int[count];
		for (int i = 0; i < count; i++) {
			unionSet[i] = i;
			sz[i] = 1;
		}
	}

	void union(int p, int q) {
		int pid = root(p);
		int qid = root(q);

		if (pid == qid)
			return;

		if (sz[pid] > sz[qid]) {
			unionSet[qid] = pid;
			sz[pid] += sz[qid];
		} else {
			unionSet[pid] = qid;
			sz[qid] += sz[pid];
		}
	}

	boolean connected(int p, int q) {
		return root(p) == root(q);
	}

	int root(int p) {
		while (unionSet[p] != p)
			p = unionSet[p];
		return p;
	}

}
