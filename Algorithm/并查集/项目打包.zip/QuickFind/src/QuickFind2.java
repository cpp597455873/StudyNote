public class QuickFind2 {

	int[] unionSet;
	int count;

	public QuickFind2(int count) {
		this.count = count;
		unionSet = new int[count];
		for (int i = 0; i < unionSet.length; i++) {
			unionSet[i] = i;
		}
	}

	void union(int p1, int p2) {
		int p1id = unionSet[p1];
		int p2id = unionSet[p2];

		if (p1id == p2id)
			return;
		for (int i = 0; i < count; i++) {
			if (p1id == unionSet[i]) {
				unionSet[i] = p2id;
			}
		}

	}

	boolean connected(int p1, int p2) {
		return unionSet[p1] == unionSet[p2];
	}

}
